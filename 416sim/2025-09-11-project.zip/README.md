To run:
1. Extract the files.
2. Open index.html in a web browser.

Note:
The python file will run as a streamlit app but the streamlit iframe is not sized correctly so you will not be able to use all the controls. It is recommended to use the native html file.

You must add series to see the speed flow density plots.
Multiple series currently do not work due to limitations in the uplot library.